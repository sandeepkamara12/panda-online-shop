import React from 'react'

const ProductDescription = ({description}) => {
  return (
      <p>{description}</p>
  )
}

export default ProductDescription

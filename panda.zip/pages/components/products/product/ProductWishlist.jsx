import React from 'react'

const ProductWishlist = () => {
  return (
    <div className="product-action-vertical">
      <a href="#" className="btn-product-icon btn-wishlist btn-expandable"><span>Add to wishlist</span></a>
      {/* <a href="popup/quickView.html" className="btn-product-icon btn-quickview" title="Quick view"><span>Quick view</span></a>
      <a href="#" className="btn-product-icon btn-compare" title="Compare"><span>Compare</span></a> */}
    </div>
  )
}

export default ProductWishlist
